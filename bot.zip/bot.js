const { Client, GatewayIntentBits } = require('discord.js');
const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.MessageContent, GatewayIntentBits.GuildMessages] });

const { EmbedBuilder } = require('discord.js');

client.on('messageCreate', message => {
  if (message.author.bot) return;

  const prefix = '+rep';
  if (message.content.startsWith(prefix)) {
    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const mention = message.mentions.users.first();
    if (!mention) {
      message.channel.send('Please mention a user to give rep to.');
      return;
    }
    args.shift(); // remove mention

    const amount = args[0];
    if (!amount) {
      message.channel.send('Please specify the amount (e.g. "1x").');
      return;
    }

    const plnIndex = args.findIndex(arg => arg.toUpperCase() === 'PLN');
    if (plnIndex === -1) {
      message.channel.send('Please include price followed by PLN.');
      return;
    }

    const price = args[plnIndex - 1];
    if (!price) {
      message.channel.send('Please specify the price before PLN.');
      return;
    }

    const whatYouBuy = args.slice(1, plnIndex - 1).join(' ');
    if (!whatYouBuy) {
      message.channel.send('Please specify what you bought.');
      return;
    }

    const payMethod = args.slice(plnIndex + 1).join(' ');
    if (!payMethod) {
      message.channel.send('Please specify the pay method.');
      return;
    }

    const sender = message.author;

    const embed = new EmbedBuilder()
      .setColor('#32CD32') // lime color
      .setTitle('Dziękuję za złożenie legitchecka!')
      .addFields(
        { name: 'kto', value: `<@${sender.id}>`, inline: true },
        { name: 'komu', value: `<@${mention.id}>`, inline: true },
        { name: 'Zakup', value: `${amount} ${whatYouBuy} za ${price} PLN` },
        { name: 'Metoda płatności', value: payMethod }
      )
      .setFooter({ text: 'Zapraszamy ponownie!' });

    message.channel.send({ embeds: [embed] });
  }
});

client.on('messageCreate', async (message) => {
  if (message.author.bot) return;

  if (message.content === '!stworzmenu') {
    const filter = (m) => m.author.id === message.author.id;

    // Pytanie o opis wiadomości
    await message.channel.send('Podaj opis wiadomości');
    let opis;
    try {
      const collectedOpis = await message.channel.awaitMessages({ filter, max: 1, time: 120000, errors: ['time'] });
      opis = collectedOpis.first().content;
    } catch {
      return message.channel.send('Przekroczono czas na wpisanie opisu.');
    }

    // Pytanie o kolor
    await message.channel.send('Podaj kolor (np. #ff0000 lub red)');
    let kolor;
    try {
      const collectedKolor = await message.channel.awaitMessages({ filter, max: 1, time: 120000, errors: ['time'] });
      kolor = collectedKolor.first().content;
    } catch {
      return message.channel.send('Przekroczono czas na wpisanie koloru.');
    }

    // Tworzenie i wysyłanie embed
    const embed = new EmbedBuilder()
      .setDescription(opis)
      .setColor(kolor);

    await message.channel.send({ content: '', embeds: [embed] });
  }
});


client.login('MTM3MzMwNjM1NDcwNTM2NzE3Mg.GrjStR.LRN2iCs098bkXJiXAYOFg3gQ9ZWtExF9XGG9M4');